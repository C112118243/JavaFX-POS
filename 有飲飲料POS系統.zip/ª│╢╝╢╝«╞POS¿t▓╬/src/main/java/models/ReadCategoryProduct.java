
package models;

import java.util.TreeMap;


public class ReadCategoryProduct {

    
     //準備好產品清單  
    public static TreeMap<String, Product> readProduct() {
        //read_product_from_file(); //從檔案或資料庫讀入產品菜單資訊
        //放所有產品  產品編號  產品物件
        TreeMap<String, Product> product_dict = new TreeMap<>();
        String[][] product_array = {
            {"YY001", "拎茶啦", "古早味憨厚紅茶", "30", "古早味憨厚紅茶.png"},
            {"YY002", "拎茶啦", "尚青四季春茶", "35", "尚青四季春茶.png"},
            {"YY003", "拎茶啦", "炭焙鐵觀音", "40", "炭焙鐵觀音.png"},
            {"YY004", "拎茶啦", "焙香黃金穀物茶", "40", "焙香黃金穀物茶.png"},
            {"YY005", "拎茶啦", "憨厚濃萃綠茶", "35", "憨厚濃萃綠茶.png"},
            {"YY006", "拎茶啦", "焦香椪糖紅茶", "40", "焦香椪糖紅茶.png"},
            {"YY007", "拎茶啦", "焦香椪糖四季春", "45", "焦香椪糖四季春.png"},
            {"YY010", "乳香奶霜", "玫瑰鹽奶霜紅", "65", "玫瑰鹽奶霜紅.png"},
            {"YY011", "乳香奶霜", "玫瑰鹽奶霜四季春", "70", "玫瑰鹽奶霜四季春.png"},
            {"YY012", "乳香奶霜", "椪糖奶霜紅", "75", "椪糖奶霜紅.png"},
            {"YY013", "乳香奶霜", "椪糖奶霜綠", "75", "椪糖奶霜綠.png"},
            {"YY014", "乳香奶霜", "厚乳抹茶奶霜", "75", "厚乳抹茶奶霜.png"},
            {"YY100", "優格飲", "原味優優", "60", "原味優優.png"},
            {"YY101", "優格飲", "草莓優優", "80", "草莓優優.png"},
            {"YY102", "優格飲", "鳳梨優優", "75", "鳳梨優優.png"},
            {"YY103", "優格飲", "椪糖優優", "70", "椪糖優優.png"},
            {"YY104", "優格飲", "百香果優優", "70", "百香果優優.png"},
            {"YY1000", "涼涼ㄟ果茶", "旺旺來鐵觀音", "65", "旺旺來鐵觀音.png"},
            {"YY1001", "涼涼ㄟ果茶", "炎炎夏日水果茶", "75", "炎炎夏日水果茶.png"},
            {"YY1002", "涼涼ㄟ果茶", "青青小樹蘋果綠", "65", "青青小樹蘋果綠.png"},
            {"YY1003", "涼涼ㄟ果茶", "蜜香檸檬四季", "65", "蜜香檸檬四季.png"},
        };

        //一筆放入字典變數product_dict中
        for (String[] item : product_array) {
            Product product = new Product(
                    item[0], 
                    item[1], 
                    item[2], 
                    Integer.parseInt(item[3]), //價格轉為int
                    item[4]);
            //將這一筆放入字典變數product_dict中 
            product_dict.put(product.getProduct_id(), product);
        }
        return product_dict; 
    }
}
